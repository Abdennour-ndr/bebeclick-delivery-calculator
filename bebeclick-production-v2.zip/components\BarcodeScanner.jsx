import React, { useEffect, useRef, useState } from 'react';
import { Camera, X, AlertCircle, CheckCircle } from 'lucide-react';
import { Html5QrcodeScanner } from 'html5-qrcode';

const BarcodeScanner = ({ isOpen, onClose, onScanSuccess, onError }) => {
  const html5QrcodeScannerRef = useRef(null);
  const [error, setError] = useState(null);
  const [scanResult, setScanResult] = useState(null);

  useEffect(() => {
    if (isOpen) {
      initializeScanner();
    } else {
      stopScanning();
    }

    return () => {
      stopScanning();
    };
  }, [isOpen]);

  const initializeScanner = async () => {
    try {
      setError(null);
      console.log('🎥 Initialisation du scanner de code-barres...');

      // Vérifier si la caméra est disponible
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Caméra non supportée par ce navigateur');
      }

      // Demander l'autorisation de la caméra
      try {
        console.log('📱 Demande d\'autorisation de la caméra...');
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        // Arrêter le stream temporaire
        stream.getTracks().forEach(track => track.stop());
        console.log('✅ Autorisation de la caméra accordée');
      } catch (permissionError) {
        console.error('❌ Autorisation de la caméra refusée:', permissionError);
        throw new Error('Autorisation de la caméra requise pour scanner les codes-barres');
      }

      const config = {
        fps: 10,
        qrbox: { width: 250, height: 150 },
        aspectRatio: 1.777778,
        disableFlip: false,
        rememberLastUsedCamera: true,
        showTorchButtonIfSupported: true
      };

      console.log('🔧 Configuration du scanner:', config);

      html5QrcodeScannerRef.current = new Html5QrcodeScanner(
        "qr-reader",
        config,
        false
      );

      html5QrcodeScannerRef.current.render(
        (decodedText) => {
          console.log('✅ Code-barres scanné:', decodedText);
          setScanResult(decodedText);

          // Arrêter le scan
          if (html5QrcodeScannerRef.current) {
            html5QrcodeScannerRef.current.clear();
          }

          setTimeout(() => {
            if (onScanSuccess) {
              onScanSuccess(decodedText);
            }
            onClose();
          }, 1000);
        },
        (errorMessage) => {
          // Ignorer les erreurs de QR code non trouvé
          if (!errorMessage.includes('No QR code found') &&
              !errorMessage.includes('NotFoundException')) {
            console.warn('⚠️ Erreur de lecture du code-barres:', errorMessage);
          }
        }
      );

      console.log('✅ Scanner initialisé avec succès');

    } catch (err) {
      console.error('❌ Erreur d\'initialisation du scanner:', err);
      setError(err.message || 'Échec d\'initialisation de la caméra');
      if (onError) onError(err);
    }
  };

  const stopScanning = () => {
    try {
      if (html5QrcodeScannerRef.current) {
        html5QrcodeScannerRef.current.clear();
        html5QrcodeScannerRef.current = null;
      }
    } catch (err) {
      console.warn('Erreur d\'arrêt du scan:', err);
    }
    setScanResult(null);
  };

  const handleClose = () => {
    stopScanning();
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="barcode-scanner-overlay">
      <div className="barcode-scanner-container">
        {/* Header */}
        <div className="barcode-scanner-header">
          <h3>
            <Camera size={20} />
             Scanner un code-barres
          </h3>
          <button onClick={handleClose} className="barcode-close-btn">
            <X size={20} />
          </button>
        </div>

        {/* Instructions */}
        <div className="mb-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="flex items-center space-x-2 text-blue-800">
            <Camera size={16} />
            <span className="text-sm font-medium">
              Autorisez l'accès à la caméra pour scanner les codes-barres
            </span>
          </div>
        </div>

        {/* Scanner Container */}
        <div className="barcode-video-container">
          {error ? (
            <div className="barcode-error">
              <AlertCircle size={48} />
              <p>{error}</p>
              <div className="mt-4 space-y-2">
                <button onClick={initializeScanner} className="barcode-retry-btn">
                  Réessayer
                </button>
                <div className="text-sm text-gray-600 mt-2">
                  <p>💡 Assurez-vous que:</p>
                  <ul className="list-disc list-inside mt-1 space-y-1">
                    <li>Votre navigateur supporte la caméra</li>
                    <li>Vous avez autorisé l'accès à la caméra</li>
                    <li>Aucune autre application n'utilise la caméra</li>
                  </ul>
                </div>
              </div>
            </div>
          ) : (
            <>
              <div id="qr-reader" style={{ width: '100%' }}></div>

              {/* Success Indicator */}
              {scanResult && (
                <div className="barcode-success">
                  <CheckCircle size={48} />
                  <p>Code-barres scanné avec succès!</p>
                  <code>{scanResult}</code>
                </div>
              )}
            </>
          )}
        </div>


      </div>
    </div>
  );
};

export default BarcodeScanner;
